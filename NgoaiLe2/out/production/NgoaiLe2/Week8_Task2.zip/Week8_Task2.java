import java.io.*;
import java.util.ArrayList;

public class Week8_Task2{

    // NullPointerException
    public static int NPEx(String line){
        return line.length();
    }

    public static String NPExTest(String line) throws NullPointerException{
        if(Week8_Task2.NPEx(line) == 0) throw new NullPointerException("Lỗi Null Pointer");
        return "Không có lỗi";
    }


    // ArrayINdexOutOfBoundsException
    public static int AIOoBEx(int[] arr){
        return arr[arr.length];
    }

    public static String AIOoBExTest(int[] arr) throws ArrayIndexOutOfBoundsException{
        if(Week8_Task2.AIOoBEx(arr) == -1) throw new ArrayIndexOutOfBoundsException("Lỗi Array INdex Out OF Bounds");
        return "Không có lỗi";
    }

    // Arithmetic Exception
    public static int ArithEx(int a, int b){
        return a/b;
    }

    public static String ArithExTest(int a, int b) throws ArithmeticException{
        if(Week8_Task2.ArithEx(a,b)==-1) throw new ArithmeticException("Lỗi Arithmetic");
        return "Không có lỗi";
    }

    //File Not Found Exception
    public static void FNFEx(String path) throws IOException {
        FileReader fr = new FileReader(path);
        while(fr.read() != -1){
            System.out.println(fr.read());
        }
    }

    public static String FNFExTest(String path){
       return null;
    }


}
