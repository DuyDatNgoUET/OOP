interface GeometricObject {
    public double getArea();
    public double getPerimeter();
    String getInfo();
}
