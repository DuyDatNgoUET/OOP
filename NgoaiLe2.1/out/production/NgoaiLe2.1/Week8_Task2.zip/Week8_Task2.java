public class Week8_Task2 {

    // Null Pointer Exception
    Object NPEx() throws NullPointerException{
        Object o = null;
        return o;
    }

    String NPExTest(){
        try{
            Object a = NPEx();
            return "Không có lỗi";
        }catch (NullPointerException npe){
            return "Lỗi Null Pointer";
        }
    }

}
